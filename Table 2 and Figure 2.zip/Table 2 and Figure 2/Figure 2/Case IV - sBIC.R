###########################  CASE ONE with K0=3, K=1, 2, 3, 4
## NULL Setting
n<-500  ## n=100, 200, 300, 400, and 500.
N<-1000
L<-15

sBIC1<-NULL
sBIC2<-NULL
sBIC3<-NULL
sBIC4<-NULL
U3<-NULL

# EM Estimation
for (f in 1:N)
{
  ## True parameters 
  beta1<-c(1.2, 0, 0.5)
  beta2<-c(1.2, 0, -0.8)
  a<-c(0.5, 0, 0.7)
  b<-c(0.6, 0, -0.5)
  c<-c(-1, 0, 1)
  sigma1<-c(0.6, 0.4, 0.5)
  sigma2<-c(0.5, 0.7, 0.6)
  alpha<-c(0.2, 0.5, 0.3)
  ## Sample 
  Y<-NULL
  M<-NULL
  n1<-floor(n*alpha[1])
  n2<-floor(n*alpha[2])
  n3<-n-n1-n2
  X<-rnorm(n)
  M[1:n1]<-beta1[1]+a[1]*X[1:n1]+rnorm(n1)*sigma1[1]
  Y[1:n1]<-beta2[1]+c[1]*X[1:n1]+b[1]*M[1:n1]+rnorm(n1)*sigma2[1]
  M[(1+n1):(n1+n2)]<-beta1[2]+a[2]*X[(1+n1):(n1+n2)]+rnorm(n2)*sigma1[2]
  Y[(1+n1):(n1+n2)]<-beta2[2]+c[2]*X[(1+n1):(n1+n2)]+b[2]*M[(1+n1):(n1+n2)]+rnorm(n2)*sigma2[2]
  M[(1+n1+n2):n]<-beta1[3]+a[3]*X[(1+n1+n2):n]+rnorm(n3)*sigma1[3]
  Y[(1+n1+n2):n]<-beta2[3]+c[3]*X[(1+n1+n2):n]+b[3]*M[(1+n1+n2):n]+rnorm(n3)*sigma2[3]
  U<-rep(1, n)
  V<-matrix(c(U, X), ncol=2)
  Z<-matrix(c(U, X, M), ncol=3)
  
  ##############################  K=1 
  ## Estimation for K=1
  beta1_hat<-(solve(t(V)%*%V)%*%t(V)%*%M)[1]
  a_hat<-(solve(t(V)%*%V)%*%t(V)%*%M)[2]
  beta2_hat<-(solve(t(Z)%*%Z)%*%t(Z)%*%Y)[1]
  c_hat<-(solve(t(Z)%*%Z)%*%t(Z)%*%Y)[2]
  b_hat<-(solve(t(Z)%*%Z)%*%t(Z)%*%Y)[3]
  sigma1_hat<-sqrt(sum((M-beta1_hat-a_hat*X)^2)/n)
  sigma2_hat<-sqrt(sum((Y-beta2_hat-c_hat*X-b_hat*M)^2)/n)
  
  ## sBIC for K=1
  K<-1
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  for (i in 1:n){
    P[i]<-sapply(M[i], dnorm, beta1_hat+a_hat*X[i], sigma1_hat)
    Q[i]<-sapply(Y[i], dnorm, beta2_hat+c_hat*X[i]+b_hat*M[i], sigma2_hat)
    H[i]<-P[i]*Q[i]
  }
  L_11<-prod(H*L)/n^(7/2)
  sBIC1[f]<-log(L_11)-n*log(L)
  
  ########################### K=2
  ## Initialization parameters
  K<-2
  beta1<-runif(K)
  beta2<-runif(K)
  a<-runif(K)
  b<-runif(K)
  c<-runif(K)
  d<-runif(1, 0.4, 0.6)
  alpha<-c(d,1-d)
  sigma1<-runif(K, 0.5, 1)
  sigma2<-runif(K, 0.5, 1)
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  ## Circle
  for (S in 1:200){
    ## E-step
    for (j in 1:K){
      for (i in 1:n){
        P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
        Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
        H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
      }
    }
    H<-H/rowSums(H)
    oldbeta1<-beta1
    oldbeta2<-beta2
    olda<-a
    oldb<-b
    oldc<-c
    oldalpha<-alpha
    oldsigma1<-sigma1
    oldsigma2<-sigma2
    ## M-step
    for (j in 1:K){
      alpha[j]<-sum(H[,j])/sum(H)
      beta1[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[1]
      a[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[2]
      beta2[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[1]
      c[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[2]
      b[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[3]
      sigma1[j]<-{(M-c(beta1[j], a[j])%*%t(V))%*%diag(H[,j])%*%t(M-c(beta1[j], a[j])%*%t(V))/sum(H[,j])}^0.5
      sigma2[j]<-{(Y-c(beta2[j], c[j], b[j])%*%t(Z))%*%diag(H[,j])%*%t((Y-c(beta2[j], c[j], b[j])%*%t(Z)))/sum(H[,j])}^0.5
    }
    ## Change condition
    espsilo<-1e-5
    if (sum(abs(a-olda)<espsilo) &
        sum(abs(b-oldb)<espsilo) &
        sum(abs(alpha-oldalpha)<espsilo)
    ) break
    cat('S', S, 'a', a, 'b', b, 'c', c,'alpha', alpha, '\n')
  }
  
  ### BIC2 for K=2
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  for (j in 1:K){
    for (i in 1:n){
      P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
      Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
      H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
    }
  }
  L_21<-prod((H[,1]+H[,2])*L)/n^(14/2)
  L_22<-prod((H[,1]+H[,2])*L)/n^(15/2)
  B<-L_11-L_22
  C<-L_21*L_11
  L_2<-(sqrt(B^2+4*C)-B)/2
  sBIC2[f]<-log(L_2)-n*log(L)
  
  ######################## K=3
  ## Initialization parameters
  K<-3
  beta1<-runif(K)
  beta2<-runif(K)
  a<-runif(K)
  b<-runif(K)
  c<-runif(K)
  d1<-runif(1, 0.3, 0.4)
  d2<-runif(1, 0.3, 0.4)
  alpha<-c(d1, d2, 1-d1-d2)
  sigma1<-runif(K, 0.5, 0.6)
  sigma2<-runif(K, 0.5, 0.6)
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  R<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  ## Circle
  for (S in 1:500){
    ## E-step
    for (j in 1:K){
      for (i in 1:n){
        P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
        Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
        H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
      }
    }
    H<-H/rowSums(H)
    oldbeta1<-beta1
    oldbeta2<-beta2
    olda<-a
    oldb<-b
    oldc<-c
    oldalpha<-alpha
    oldsigma1<-sigma1
    oldsigma2<-sigma2
    ## M-step
    for (j in 1:K){
      alpha[j]<-sum(H[,j])/sum(H)
      beta1[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[1]
      a[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[2]
      beta2[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[1]
      c[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[2]
      b[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[3]
      sigma1[j]<-{(M-c(beta1[j], a[j])%*%t(V))%*%diag(H[,j])%*%t(M-c(beta1[j], a[j])%*%t(V))/sum(H[,j])}^0.5
      sigma2[j]<-{(Y-c(beta2[j], c[j], b[j])%*%t(Z))%*%diag(H[,j])%*%t((Y-c(beta2[j], c[j], b[j])%*%t(Z)))/sum(H[,j])}^0.5
    }
    ## Change condition
    espsilo<-1e-5
    if (sum(abs(a-olda)<espsilo) &
        sum(abs(b-oldb)<espsilo) &
        sum(abs(alpha-oldalpha)<espsilo)
    ) break
    cat('S', S, 'a', a, 'b', b, 'alpha', alpha, '\n')
  }
  
  ### BIC3 for K=3
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  for (j in 1:K){
    for (i in 1:n){
      P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
      Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
      H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
    }
  }
  L_31<-prod((H[,1]+H[,2]+H[,3])*L)/n^(21/2)
  L_32<-prod((H[,1]+H[,2]+H[,3])*L)/n^(22/2)
  L_33<-prod((H[,1]+H[,2]+H[,3])*L)/n^(23/2)
  B<-L_11+L_2-L_33
  C<-L_31*L_11+L_32*L_2
  L_3<-(sqrt(B^2+4*C)-B)/2
  sBIC3[f]<-log(L_3)-n*log(L)
  
  ## Initialization for K=4
  K<-4
  beta1<-c(beta1, 0.1)
  beta2<-c(beta2, 0.1)
  a<-c(a, 0.1)
  b<-c(b, 0.1)
  c<-c(c, 0.1)
  alpha<-c(alpha, 0.1)
  sigma1<-c(sigma1, 1)
  sigma2<-c(sigma2, 1)
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  R<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  ## EM for interation
  for (S in 1:500){
    ## E-step
    for (j in 1:K){
      for (i in 1:n){
        P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
        Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
        H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
      }
    }
    H<-H/rowSums(H)
    oldbeta1<-beta1
    oldbeta2<-beta2
    olda<-a
    oldb<-b
    oldc<-c
    oldalpha<-alpha
    oldsigma1<-sigma1
    oldsigma2<-sigma2
    ## M-step
    for (j in 1:K){
      alpha[j]<-sum(H[,j])/sum(H)
      beta1[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[1]
      a[j]<-(solve(t(V)%*%diag(H[,j])%*%V)%*%t(V)%*%diag(H[,j])%*%M)[2]
      beta2[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[1]
      c[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[2]
      b[j]<-(solve(t(Z)%*%diag(H[,j])%*%Z)%*%t(Z)%*%diag(H[,j])%*%Y)[3]
      sigma1[j]<-{(M-c(beta1[j], a[j])%*%t(V))%*%diag(H[,j])%*%t(M-c(beta1[j], a[j])%*%t(V))/sum(H[,j])}^0.5
      sigma2[j]<-{(Y-c(beta2[j], c[j], b[j])%*%t(Z))%*%diag(H[,j])%*%t((Y-c(beta2[j], c[j], b[j])%*%t(Z)))/sum(H[,j])}^0.5
    }
    ## change for one round
    espsilo<-1e-5
    if (sum(abs(a-olda)<espsilo) &
        sum(abs(b-oldb)<espsilo) &
        sum(abs(alpha-oldalpha)<espsilo)
    ) break
    cat('S', S, 'a', a, 'b', b, 'alpha', alpha, '\n')
  }
  ### BIC4 for K=4
  P<-matrix(rep(0,n*K),ncol=K)
  Q<-matrix(rep(0,n*K),ncol=K)
  H<-matrix(rep(0,n*K),ncol=K)
  for (j in 1:K){
    for (i in 1:n){
      P[i,j]<-sapply(M[i], dnorm, beta1[j]+a[j]*X[i], sigma1[j])
      Q[i,j]<-sapply(Y[i], dnorm, beta2[j]+c[j]*X[i]+b[j]*M[i], sigma2[j])
      H[i,j]<-alpha[j]*P[i,j]*Q[i,j]
    }
  }
  L_41<-prod((H[,1]+H[,2]+H[,3]+H[,4])*L)/n^(28/2)
  L_42<-prod((H[,1]+H[,2]+H[,3]+H[,4])*L)/n^(29/2)
  L_43<-prod((H[,1]+H[,2]+H[,3]+H[,4])*L)/n^(30/2)
  L_44<-prod((H[,1]+H[,2]+H[,3]+H[,4])*L)/n^(31/2)
  B<-L_11+L_2+L_3-L_44
  C<-L_41*L_11+L_42*L_2+L_43*L_3
  L_4<-(sqrt(B^2+4*C)-B)/2
  sBIC4[f]<-log(L_4)-n*log(L)
  
  ### Comparison
  U3[f]<-which.max(c(sBIC1[f], sBIC2[f], sBIC3[f], sBIC4[f]))
}



########### model selection number based on sBIC 
V3<-NULL
length(U3[U3==1])
length(U3[U3==2]) 
V3[n/100]<-length(U3[U3==3]) ## This is consistent selection. 
length(U3[U3==3])

########## Repeat the above procedure for n=100, 200, 300, 400, 500. 
Compute V3[1:5] for Figure 2 (green). 




########################### Plot Figure 2 based on V1-V3
#############################  sBIC for simulation 
install.packages("ggplot2")
library(ggplot2)

K<-seq(100,500,by=100)
s1<-c(918, 985, 1000, 1000, 1000)/1000
s2<-c(965, 991, 1000, 1000, 1000)/1000
s3<-c(603, 879, 904, 957, 978)/1000
n<-rep(K, 3)
Proportion<-c(s1, s2, s3)
Case<-c(rep("I", 5), rep("II", 5),rep("III", 5))

Data<-data.frame(Case, n, Proportion) 

ggplot(Data, aes(x = n, y = Proportion, fill = Case))+
  labs(x = "Sample size n")+
  geom_col(position = "dodge")






