
########################### Plot Figure 2 based on V1-V3
#############################  sBIC for simulation 
install.packages("ggplot2")
library(ggplot2)

K<-seq(100,500,by=100)
s1<-c(918, 985, 1000, 1000, 1000)/1000
s2<-c(965, 991, 1000, 1000, 1000)/1000
s3<-c(603, 879, 904, 957, 978)/1000
n<-rep(K, 3)
Proportion<-c(s1, s2, s3)
Case<-c(rep("I", 5), rep("II", 5),rep("III", 5))

Data<-data.frame(Case, n, Proportion) 

ggplot(Data, aes(x = n, y = Proportion, fill = Case))+
  labs(x = "Sample size n")+
  geom_col(position = "dodge")


########################### Plot Figure 2 based on V1-V4
#############################  sBIC for simulation 
library(ggplot2)

K<-seq(100,500,by=100)
s1<-c(918, 985, 1000, 1000, 1000)/1000
s2<-c(965, 991, 1000, 1000, 1000)/1000
s3<-c(925, 987, 1000, 1000, 1000)/1000
s4<-c(603, 879, 904, 957, 978)/1000
n<-rep(K, 4)
Proportion<-c(s1, s2, s3, s4)
Case<-c(rep("I", 5), rep("II", 5),rep("III", 5), rep("IV", 5))

Data<-data.frame(Case, n, Proportion) 

ggplot(Data, aes(x = n, y = Proportion, fill = Case))+
  labs(x = "Sample size n")+
  geom_col(position = "dodge")



